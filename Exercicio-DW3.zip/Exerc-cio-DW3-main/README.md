# Tarefa Dev Web

Para gerar o token de autenticação é necessário fazer o login na rota user/login passando o id do usuário.

Será retornado o access-token, este deverá ser passsado nos Headers como "access-token" para que as requisições sejam autorizadas