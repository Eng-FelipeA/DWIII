const express = require('express')
const bodyParser = require('body-parser')
const app = express()

const userRoute = require('./src/routes/usuarioRoute')
const projectRoute = require('./src/routes/projectRoute')
app.use(projectRoute)
app.use(userRoute)

//Configurando a conexão

const mongoose = require('mongoose')
let url = 'mongodb+srv://felipevieira31:<password>@fatec.9pqfit0.mongodb.net/?retryWrites=true&w=majority&appName=Fatec'
let mongoDB = process.env.MONGODB_URI || url
mongoose.connect(mongoDb)
mongoose.Promise = globa.Promise
let db = mongoose.connection;
db.on('error', console.error.bind(console, 'Erro ao conectar o banco de dados'))

app.use(bodyParser.jason())
app.use(bodyParser.urlencoded({extended: false}))





app.listen(3000, () =>{
    console.log('Servidor em execução na porta 3000')
})