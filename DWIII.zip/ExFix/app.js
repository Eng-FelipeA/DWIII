const express = require('express')
const app = express()
const port = 3000

const veiculos = [];

app.put('/', (req, res) => {
    const index = veiculos.findIndex(x => x.id == req.query.id);
    veiculos[index] = {id: req.query.id, name: req.body.name}
    res.send(JSON.stringify(veiculos))
})

app.delete('/', (req, res) => {
    const index = veiculos.findIndex(x => x.id == req.query.id);
    veiculos.splice(index, 1);
    res.send(JSON.stringify(veiculos))
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})