# MVC
[![License: MIT](https://img.shields.io/badge/License-MIT-purple.svg)](https://opensource.org/licenses/MIT)

Simples GitHub App em JavaScript

### [Ler o tutorial](https://www.isarubim.com/construindo-um-simples-projeto-mvc-do-zero-com-javascript) | [Ver demonstração](https://mvc-isarubim.netlify.app/)

## Autora

- [Isabel Rubim](https://www.isarubim.com)

## License

This project is open source and available under the [MIT License](LICENSE).
