﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp1.Controller
{
    class Class1
    {
    }
}
