﻿using System;
using System.Collections.Generic;
using System.Text;
using WindowsFormsApp1.Model.Data;

namespace WindowsFormsApp1.Data
{
    class VilaoModel : IData
    {
        public bool Create(object objeto)
        {
            throw new NotImplementedException();
        }

        public bool Delete(object objeto)
        {
            throw new NotImplementedException();
        }

        public bool Read(object objeto)
        {
            throw new NotImplementedException();
        }

        public List<object> Read()
        {
            throw new NotImplementedException();
        }

        public bool Update(object objeto)
        {
            throw new NotImplementedException();
        }
    }
}
