﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1.View
{
    public partial class VilaoView : Form
    {
        public VilaoView()
        {
            InitializeComponent();
        }
    }
}
