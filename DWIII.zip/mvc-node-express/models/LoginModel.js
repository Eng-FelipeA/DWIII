module.exports = class LoginModel{
    constructor(){}

    isLogged(){
        return "logado"
        }
}