module.exports = class AlunoModel{

    constructor(){}

    pessoas = [
        {
            'nome': 'Daniela',
            'idade': 17
        },
        {
            'nome': 'João',
            'idade': 21,
        },
        {
            'nome': 'Pedro',
            'idade': 25,
        },
    ]
}