const express= require('express')
const app = express()
const loginRoute = require('./routes/LoginRoute')
const alunosRoute = require('./routes/AlunosRoute')
const swaggerUi = require('swagger-ui-express');
const swaggerFile = require('./swagger-output.json');
const bodyParser = require('body-parser');


app.set('view engine', 'ejs') 
app.set('views', './views/login')
app.set('views', './views/alunos')

app.use(loginRoute)
app.use(alunosRoute)

app.use(bodyParser.json());
app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerFile));

app.listen(3000,function(){
    console.log("App rodando na porta 3000")
})