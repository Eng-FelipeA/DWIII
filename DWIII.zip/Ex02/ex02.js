const express = require('express');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.json());

let notas = [];

// Rota para adicionar uma nota
app.post('/notas', (req, res) => {
    const novaNota = req.body.nota;
    if (novaNota >= 0 && novaNota <= 100) {
        notas.push(novaNota);
        res.status(201).json({ message: 'Nota adicionada com sucesso!' });
    } else {
        res.status(400).json({ error: 'A nota deve estar entre 0 e 100.' });
    }
});

// Rota para obter estatísticas sobre as notas
app.get('/estatisticas', (req, res) => {
    if (notas.length === 0) {
        res.status(404).json({ error: 'Nenhuma nota encontrada.' });
    } else {
        const media = notas.reduce((acc, nota) => acc + nota, 0) / notas.length;
        const abaixoMedia = notas.filter(nota => nota < 60).length;
        const naMedia = notas.length - abaixoMedia;
        res.status(200).json({ media, abaixoMedia, naMedia });
    }
});

const port = 3000;
app.listen(port, () => {
    console.log(`Servidor ouvindo na porta ${port}`);
});