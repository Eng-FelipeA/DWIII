const mongoose = require('mongoose')
const Schema = mongoose.Schema
let projectSchema = new Schema({
    title:{
        type: String,
        require: true,
        max: 100
    },
    description:{
        type: String,
        require: true
    },
    assignedTo:{
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User'
    }
});
module.exports = mongoose.model('Project', projectSchema)