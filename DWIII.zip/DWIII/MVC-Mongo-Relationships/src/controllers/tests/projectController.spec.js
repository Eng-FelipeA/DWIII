//const {testEnvironment} = require('../../../jest.config')
//const jestConfig = require('../../../jest.config')
const projectController = require('../projectController')

//jest.mock('../projectController')

describe("Project Controller", () => {
    test("Shoud create a new project", () => {
    const req = {
        body:{
        title: 'Teste',
        description: 'Project Description',
        assignedTo: 123456
        }
    }
    const res = {
        status: jest.fn().mockReturnThis,
        send: jest.fn()
    }
    projectController.create(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
})})
